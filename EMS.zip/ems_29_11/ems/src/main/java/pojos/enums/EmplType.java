package pojos.enums;

public enum EmplType {
	FULL_TIME, PART_TIME, CONTRACT, PERMANENT;
}
